CREATE TABLE "orders" (
	"id" text PRIMARY KEY,
	"name" text NOT NULL,
	"phone" text NOT NULL,
	"method" text NOT NULL,
	"address" text NOT NULL,
	"notes" text NOT NULL,
	"transfer_reference" text NOT NULL,
	"items" jsonb NOT NULL,
	"total" integer NOT NULL,
	"payment_status" text DEFAULT 'reported_pending_verification' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
